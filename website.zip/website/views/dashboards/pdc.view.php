<?php require base_path('views/partials/auth/auth.php') ?>

<main>
    <div class="">
        PDC Dashboard
    </div>
</main>


<?php require base_path('views/partials/auth/auth-close.php') ?>
