<?php require base_path(path: 'views/partials/auth/auth.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Report</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="/styles/pasindu/report.css">
</head>
<body>
    <div class="container">
        <div class="report-container">
            <h1>Company Report</h1>

            <div class="form-group">
                <label for="companyName">Company Name:</label>
                <input type="text" id="companyName" placeholder="Enter company name" required>
            </div>

            <div class="form-group">
                <label for="companyID">Company ID No:</label>
                <input type="text" id="companyID" placeholder="Enter company ID" required>
            </div>

            <div class="form-group">
                <label for="internStudents">Intern Students:</label>
                <input type="text" id="internStudents" placeholder="Enter number of intern students" required>
            </div>

            <div class="form-group">
                <label>What Rate this Company:</label>
                <div class="rating-container">
                    <span class="material-symbols-outlined rating-icon">star</span>
                    <span class="material-symbols-outlined rating-icon">star</span>
                    <span class="material-symbols-outlined rating-icon">star</span>
                    <span class="material-symbols-outlined rating-icon">star</span>
                    <span class="material-symbols-outlined rating-icon">star</span>
                </div>
            </div>

            <div class="form-group">
                <label for="note">Note:</label>
                <textarea id="note" placeholder="Enter any additional notes" required></textarea>
            </div>

            <button id="submitButton" class="submit-button">Submit</button>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
<?php require base_path('views/partials/auth/auth-close.php') ?>
