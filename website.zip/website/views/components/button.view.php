<button type="button" class="button is-primary">
    <?= $text ?>
</button>