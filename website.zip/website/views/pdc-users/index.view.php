<?php require base_path('views/partials/auth/auth.php') ?>

<main>
    <div class="">
        pdc users index
    </div>
</main>


<?php require base_path('views/partials/auth/auth-close.php') ?>
