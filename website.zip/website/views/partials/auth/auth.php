<?php require base_path('views/partials/head.php') ?>
<?php require base_path('views/partials/nav.php') ?>

<div style="display: grid; grid-template-columns: 50px 1fr; gap: 0.5rem;">
    <div></div>
    <div>