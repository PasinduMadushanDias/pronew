
</div>

<?php require base_path('views/partials/foot.php') ?>