<?php require base_path('views/partials/head.php') ?>

<div class="mx-2 mt-2">
