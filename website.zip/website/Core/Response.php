<?php

namespace Core;

class Response
{
    public const NOT_FOUND = 404;
    public const FORBIDDEN = 403;
}