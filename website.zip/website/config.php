<?php

return [
    'database' => [
        'host' => 'aws-0-ap-southeast-1.pooler.supabase.com',
        'port' => 6543,
        'user' => 'postgres.nqxowqbchzwpdhiogtgw',
        'password' => 'vyvwe3-xegNyt-wunxow',
        'dbname' => 'postgres',
        'charset' => 'utf8mb4',
    ]
];