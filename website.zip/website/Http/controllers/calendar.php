<?php

view('lecturer/calendar.view.php', []);