<?php

view('admin/temptemp.view.php', []);