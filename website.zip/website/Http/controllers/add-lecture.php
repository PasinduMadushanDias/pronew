<?php

view('admin/add-lecture.view.php', []);