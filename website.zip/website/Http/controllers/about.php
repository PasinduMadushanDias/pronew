<?php

view('about.view.php', [
    'heading' => 'About'
]);