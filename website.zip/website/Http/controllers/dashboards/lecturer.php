<?php

view('dashboards/lecturer.view.php');
