<?php

view('dashboards/student.view.php');
