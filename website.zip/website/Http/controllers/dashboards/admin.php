<?php

view('dashboards/admin.view.php');