<?php

view('lecturer/report.view.php', []);