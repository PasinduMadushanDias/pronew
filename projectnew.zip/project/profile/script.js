document.addEventListener('DOMContentLoaded', function() {
    const saveButton = document.querySelector('.save-button');

    saveButton.addEventListener('click', function() {
        // Here you can add the logic to save the changed profile details
        alert('Profile details saved successfully!');
    });
});